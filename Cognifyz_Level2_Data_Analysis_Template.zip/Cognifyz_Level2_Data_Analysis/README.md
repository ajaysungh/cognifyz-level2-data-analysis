# Cognifyz Data Analysis Internship – Level 2

## Tasks
1. Restaurant Ratings
2. Cuisine Combination
3. Geographic Analysis
4. Restaurant Chains

## Submission structure
- Task_1_Restaurant_Ratings/Task_1_Restaurant_Ratings.ipynb
- Task_2_Cuisine_Combination/Task_2_Cuisine_Combination.ipynb
- Task_3_Geographic_Analysis/Task_3_Geographic_Analysis.ipynb
- Task_4_Restaurant_Chains/Task_4_Restaurant_Chains.ipynb
- data/  → original Cognifyz CSV dataset
- outputs/  → charts/results
- requirements.txt

Run every notebook from top to bottom before creating the final ZIP.
Submit the final ZIP through the official Cognifyz submission form.
